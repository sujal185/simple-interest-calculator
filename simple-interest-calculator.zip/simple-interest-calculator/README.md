# Simple Interest Calculator

A simple calculator that calculates simple interest based on the principal amount, annual interest rate, and time period.

## Formula

**Simple Interest = (Principal × Rate × Time) / 100**

## How to use

1. Enter the principal amount.
2. Enter the annual interest rate.
3. Enter the time period in years.
4. Click **Calculate Interest**.
5. The simple interest and total amount will be displayed.

## Technologies

- HTML
- CSS
- JavaScript
